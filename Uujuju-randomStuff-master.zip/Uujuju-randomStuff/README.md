# Random Stuff
A mod that adds a bunch of random stuff for minustry.
<br> Still in beta

## The mod adds: 
`Items`: 2
<br>`Blocks`: 9
<br>`Turrets`: 2
<br>`units`: 4

## planets
Currently random stuff has a planet called takamaki.

`tahamaki`: takamaki is a floating rock with spores that dissapears when you get too close

